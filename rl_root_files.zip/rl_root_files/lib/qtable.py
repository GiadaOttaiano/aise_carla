# #
# # MIT License
# # Copyright (c) 2018 Valentyn N Sichkar
# # github.com/sichkar-valentyn
# #
# # Reference to:
# # Valentyn N Sichkar. Reinforcement Learning Algorithms for global path planning // GitHub platform. DOI: 10.5281/zenodo.1317899



# Importing libraries
import time

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
# Importing function from the env.py



# # Creating class for the Q-learning table
# class QTable:
#     def __init__(self, state_size, action_size, _learning_rate, _discount):
        
#         self.state_size = state_size
#         self.action_size = action_size
#         self.learning_rate = _learning_rate
#         self.discount = _discount
#         # 3 EV state var and 5 for each V
#         self.vehicles_number = int((self.state_size - 3) / 5)

#         # Discretization
#         self.numBins_speed = 40
#         self.numBins_dist = 40
#         self.numBins_head = 30

#         self.bins = [
#             np.linspace(-27, 27, self.numBins_speed),  # EV_speed_X
#             np.linspace(-27, 27, self.numBins_speed),  # EV_speed_Y
#             np.linspace(-3.14, 3.14, self.numBins_head),  # EV_head (atan2)
#         ] + [
#             np.linspace(-3.14, 3.14, self.numBins_head)  # Duplicated V_head (atan2)
#             for _ in range(self.vehicles_number)
#         ] + [
#             np.linspace(-40, 40, self.numBins_dist),  # V_dist_X
#             np.linspace(-40, 40, self.numBins_dist),  # V_dist_Y
#             np.linspace(-27, 27, self.numBins_speed),  # V_speed_diff_X
#             np.linspace(-27, 27, self.numBins_speed)   # V_speed_diff_Y
#         ]

#         # Get the number of bins for each parameter
#         bin_sizes = [len(bins) - 1 for bins in self.bins]  # -1 because np.digitize gives indices based on bin edges
#         # Define the Q-table
#         self.q_table = np.random.uniform(low=-2, high=0, size=(bin_sizes + [action_size]))

#         # self.q_table = np.random.uniform(low=-2, high=0, size=([numBins] * state_size + [action_size]))

#     def get_discrete_state(self, state):
#         stateIndex = []
#         for i in range(self.state_size):
#                 stateIndex.append(np.digitize(state[i], self.bins[i]) - 1)
#         return tuple(stateIndex)


#     def get_q_table(self):
#         return self.q_table

#     # Function for choosing the action for the agent
#     def choose_action(self, state):
#         d_state = self.get_discrete_state(state)
#         return np.argmax(self.q_table[d_state])

#     # Function for learning and updating Q-table with new knowledge
#     def learn(self, state, action, reward, next_state):
#         d_state = self.get_discrete_state(state)
#         d_next_state = self.get_discrete_state(next_state)

#         maxFutureQ = np.max(self.q_table[d_next_state])  # estimate of optiomal future value
#         currentQ = self.q_table[d_state + (action, )]  # old value
        
#         # formula to caculate all Q values
#         newQ = (1 - self.learning_rate) * currentQ + self.learning_rate * (reward + self.discount * maxFutureQ)
#         self.q_table[d_state + (action, )] = newQ  # Update qTable with new Q value




class QTable:
    def __init__(self, state_size, action_size, _learning_rate, _discount):
        self.state_size = state_size
        self.action_size = action_size
        self.learning_rate = _learning_rate
        self.discount = _discount
        # 3 EV state variables and 5 for each V
        self.vehicles_number = int((self.state_size - 3) // 5)

        # Discretization
        # self.numBins_speed = 40
        # self.numBins_dist = 40
        # self.numBins_head = 30
        # self.numBins_speed = 20
        # self.numBins_dist = 20
        # self.numBins_head = 15
        self.numBins_speed = 10
        self.numBins_dist = 10
        self.numBins_head = 7

        # Define bins for `EV` variables (3 variables)
        self.bins = [
            np.linspace(-27, 27, self.numBins_speed),  # EV_speed_X
            np.linspace(-27, 27, self.numBins_speed),  # EV_speed_Y
            np.linspace(-3.14, 3.14, self.numBins_head)  # EV_head (atan2)
        ]

        # For other vehicles: coarser granularity
        for i in range(0, self.vehicles_number):
            factor =  1  # DO NOT Reduce granularity for vehicles farther away
            # factor = 2 if i > 1 else 1  # Reduce granularity for vehicles farther away
            self.bins += [
                np.linspace(-3.14, 3.14, self.numBins_head // factor),  # Coarser V_head
                np.linspace(-40, 40, self.numBins_dist // factor),     # Coarser V_dist_X
                np.linspace(-40, 40, self.numBins_dist // factor),     # Coarser V_dist_Y
                np.linspace(-27, 27, self.numBins_speed // factor),    # Coarser V_speed_diff_X
                np.linspace(-27, 27, self.numBins_speed // factor)     # Coarser V_speed_diff_Y
    ]

        assert len(self.bins) == self.state_size, \
            f"Mismatch: bins={len(self.bins)}, state_size={self.state_size}"        # Use a dictionary for the Q-table to store only visited states


        self.q_table = {}

    def get_discrete_state(self, state):
        stateIndex = []
        for i in range(self.state_size):
            stateIndex.append(np.digitize(state[i], self.bins[i]) - 1)
        return tuple(stateIndex)

    def get_q_value(self, state, action):
        """Get the Q-value for a state-action pair, initializing to 0 if it doesn't exist."""
        d_state = self.get_discrete_state(state)
        return self.q_table.get(d_state + (action,), 0)

    def update_q_value(self, state, action, value):
        """Update the Q-value for a state-action pair."""
        d_state = self.get_discrete_state(state)
        self.q_table[d_state + (action,)] = value

    def get_q_table(self):
        return self.q_table

    # Function for choosing the action for the agent
    def choose_action(self, state):
        d_state = self.get_discrete_state(state)
        
        # If the state has no Q-values, initialize random values for all actions
        if not any(d_state + (a,) in self.q_table for a in range(self.action_size)):
            for a in range(self.action_size):
                self.q_table[d_state + (a,)] = np.random.uniform(low=-2, high=0)  # Random initialization

        # Choose the action with the highest Q-value
        return np.argmax([self.get_q_value(state, a) for a in range(self.action_size)])


    # Function for learning and updating Q-table with new knowledge
    def learn(self, state, action, reward, next_state):
        # Ensure the current state and next state are initialized in the Q-table
        d_state = self.get_discrete_state(state)
        d_next_state = self.get_discrete_state(next_state)
        
        # Initialize random values for unvisited states
        if not any(d_state + (a,) in self.q_table for a in range(self.action_size)):
            for a in range(self.action_size):
                self.q_table[d_state + (a,)] = np.random.uniform(low=-2, high=0)

        if not any(d_next_state + (a,) in self.q_table for a in range(self.action_size)):
            for a in range(self.action_size):
                self.q_table[d_next_state + (a,)] = np.random.uniform(low=-2, high=0)

        # Calculate the Q-value update
        maxFutureQ = max(self.get_q_value(next_state, a) for a in range(self.action_size))  # Optimal future value
        currentQ = self.get_q_value(state, action)  # Current Q-value

        # Update rule
        newQ = (1 - self.learning_rate) * currentQ + self.learning_rate * (reward + self.discount * maxFutureQ)
        self.update_q_value(state, action, newQ)  # Update Q-table with the new Q-value



    def _save_model(self,obj,descr):
        try:
            with open("models/table_o"+str(obj)+"_"+str(descr)+".txt", "w") as file:
                for key, value in self.q_table.items():
                    file.write(f"{key}: {value}\n")
        except Exception as e:
            print(f"Error saving Q-table: {e}")
