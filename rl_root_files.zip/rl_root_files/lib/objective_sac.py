from sac import SAC

class ObjectiveSAC:
    def __init__(self, _objective_number, _action_space, _state_space, _q_learning_rate, _p_learning_rate, _target_entropy_scale, _autotune_alpha, _alpha, _tau, _reward_decay, _batch_size, _buffer_size, _gradient_steps):
        self.obj_no = _objective_number
        self.sac = SAC(_state_space, _action_space, _q_learning_rate, _p_learning_rate, _target_entropy_scale, _autotune_alpha, _alpha, _tau, _reward_decay, _batch_size, _buffer_size, _gradient_steps)
        self.reward = -1
        self.is_satif = False

    def get_obj_no(self):
        return self.obj_no
    
    def get_action (self, observation):
        return self.sac.act(observation)
    
    def set_reward(self,reward):
        self.reward = reward

    # def learn(self,state, action, reward, next_state):
    #     self.sac.replay_single(state, action, reward, next_state, done)

    def replay(self):
        self.sac.replay()

    def update_target(self):
        self.sac.update_target()

    def memorize(self,state, action, reward, next_state, done):
        self.sac.memorize(state, action, reward, next_state, done)


    def is_satisfied (self):
        return self.is_satif
    def set_satisfied(self):
        self.is_satif = True