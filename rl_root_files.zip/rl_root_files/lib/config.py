abs_path = "/home/conceptd/workspace/carla/"
scenario = "0"
