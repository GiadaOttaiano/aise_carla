import logging
import time

class SubtractSecondsLogger(logging.Logger):
    def __init__(self, name, subtract_seconds):
        super().__init__(name)
        self.subtract_seconds = subtract_seconds

    def makeRecord(self, name, level, fn, lno, msg, args, exc_info, func=None, extra=None, sinfo=None):
        ct = time.time() - self.subtract_seconds
        record = logging.LogRecord(name, level, fn, lno, msg, args, exc_info, func, sinfo)
        record.created = ct
        return record