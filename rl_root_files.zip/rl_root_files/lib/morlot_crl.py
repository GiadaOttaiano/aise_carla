import copy
import os.path
import random
import numpy as np
import pandas as pd
import csv

from objective import Objective
from objective_list import Objective_list
from environment import Environment
from archive import Archive
from data_handler import check_valid
from test_case import Test_Case
import logging
from datetime import datetime, timedelta
import time
from config import abs_path
import math
from crl_query import *
from crl_util import * 
from collections import deque
from logger_formatter import SubtractSecondsLogger

class MORLAT_CRL:
    def __init__(self, objectives, actions):
        self.obj_list = Objective_list()
        self.env = Environment()
        self.actions = actions
        self.archive = Archive()
        self.epsilon = 1
        self.action_count = 0
        self.total_objs = objectives
        for i in range(objectives):
            self.obj_list.add_to_list(Objective(i, actions))

        #####################################################
        self.model = None
        
        # NRS - plan after n real episodes
        self.PLAN_AFTER = 1
        # PE - number of planning simulations
        self.SIMULATIONS = 100
        # PA-B - breadth of the simulation (how many actions to plan on)
        self.ACTIONS_TO_PLAN = 10
        self.ACTIONS_RANDOM = True
        # PA-D - depth of the simulation (rollout length)
        self.ROLLOUT_STEPS = 1

        self.DISCOVERY = False
        self.MEASURE_TIME = False
        # Fixed
        self.START_PLANNING_AT = 1
        self.UPDATE_MODEL_EVERY = 1

        self.DATASET_FILE = "./dataset.csv"
        self.DOT_FILE = "./causal_graph.dot"
        self.IMG_FILE = "./causal_graph.svg"
        self.GEN_IMG_ONCE = True
        self.UPDATE_MODEL_SAMPLE = 1000000
        self.STATE_VARIABLES = 19
        self.REWARDS_VARIABLES = 6
        self.ACTION_SPACE = 17
        self.columns = []
        self.initialize_causal_graph()
        self.buffer_values = []
        self.all_values = []
        self.update_buffer = deque(maxlen=10000)
        self.numBins = 30000
        self.bins = [
            np.linspace(-10, 200, self.numBins), # 2, 157
            np.linspace(0, 10, self.numBins), # 2, 4
            np.linspace(-20, 10, self.numBins), # -12, -1
            np.linspace(-100, 100, self.numBins), # -81, 52
            np.linspace(-200, 10, self.numBins), # -157, 1
            np.linspace(-10, 10, self.numBins), # -2, 2
            np.linspace(-10, 10, self.numBins), # -5, 1
            np.linspace(-30, 30, self.numBins), # -16, 18
            np.linspace(-30, 30, self.numBins), # -21, 15
            np.linspace(-30, 30, self.numBins), # -23, 18
            np.linspace(-100, 100, self.numBins), # -12, 70
            np.linspace(-600, 600, self.numBins), # -447, 270
            np.linspace(-600, 600, self.numBins), # -170, 547
            np.linspace(0, 100, self.numBins), # 0, 100
            np.linspace(0, 90, self.numBins), # 0, 90
            np.linspace(-5, 5, self.numBins), # -1, 2
            np.linspace(-5, 5, self.numBins), # -1, 0
            np.linspace(-5, 5, self.numBins), # -1, 2
            np.linspace(-50, 200, self.numBins), # -20, 160
        ]

    def initialize_causal_graph(self):
        columns = []

        for timestep in range(self.ROLLOUT_STEPS+1):
            for observation in range(self.STATE_VARIABLES):
                columns.append("O"+str(observation)+"_"+str(timestep))

            if timestep > 0:
                for obj_reward in range(self.REWARDS_VARIABLES):
                    columns.append("R"+str(obj_reward)+"_"+str(timestep-1))

            if timestep < self.ROLLOUT_STEPS:
                columns.append("A_"+str(timestep))

        print(str(columns))
        if not self.DISCOVERY:
            print("I Generating graph")
            generate_dot(self.STATE_VARIABLES,self.REWARDS_VARIABLES, self.ROLLOUT_STEPS+1, self.DOT_FILE)
            build_img(self.DOT_FILE,self.IMG_FILE)

        self.columns = columns
        return 0
    
    def get_discrete_state(self,state):
        stateIndex = []
        for i in range(self.STATE_VARIABLES):
            stateIndex.append(np.digitize(state[i], self.bins[i]) - 1) # -1 will turn bin into index
        return stateIndex
    

    def get_obj_list(self):
        return self.obj_list

    def get_env(self):
        return self.env

    def get_actions(self):
        return self.actions

    def get_archive(self):
        return self.archive

    def choose_action(self, observation, rewards):
        self.action_count = self.action_count+1


        print("Epsilon: "+str(self.epsilon))

        if not rewards:
            return random.randint(0, len(self.actions)-1)
        uncovered_list = self.obj_list.get_all_uncovered()
        rewards_of_interests = []
        for i in range(len(rewards)):
            if i in uncovered_list:
                rewards_of_interests.append(rewards[i])
        max_index = rewards_of_interests.index(max(rewards_of_interests))
        q_table_index = uncovered_list[max_index]



        return self.obj_list.choose_action(q_table_index, observation,self.epsilon)

    def learn(self, state, action, reward, next_state):
        self.obj_list.learn(state, action, reward, next_state)

    def write_file(self, fn):
        file = open(abs_path+'RL-comps/' + fn + ".txt", 'w')
        file.write("aaa")
        file.close()

    def terminate(self):
        check_file = abs_path+"RL-comps/terminate.txt"
        if os.path.exists(check_file):
            return True
        return False

    def remove_unnecessary_files(self):
        temp_terminate_file = abs_path+"RL-comps/terminate.txt"
        if os.path.exists(temp_terminate_file):
            os.remove(temp_terminate_file)
        temp_terminate_file = abs_path+"RL-comps/start_RL.txt"
        if os.path.exists(temp_terminate_file):
            os.remove(temp_terminate_file)

    def get_logger(self, timer):
        logger = SubtractSecondsLogger(subtract_seconds=timer.get_paused_time())

        now = datetime.now()
        log_file = 'output/MORLAT/' + str(now) + '_transfuser.log'
        # Configure the logger to log to file
        file_handler = logging.FileHandler(log_file, mode="a")
        file_handler.setLevel(logging.DEBUG)
        formatter = logging.Formatter('%(asctime)s %(message)s')
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
        logger.info("Started")

        return logger
    
    def update_plan_rewards(self, rewards):
        reward_0 = 0
        reward_1 = 0
        reward_2 = 0
        reward_3 = 0
        reward_4 = 0
        reward_5 = 0

        if rewards[0] <= 0:
            reward_0 = 1000000
        if rewards[1] <= 0:
            reward_1 = 1000000
        if rewards[2] <= 0:
            reward_2 = 1000000
        if rewards[3] <= 0:
            reward_3 = 1000000

        if rewards[5] == 0:
            reward_5 = 1000000

        if reward_0 != 1000000:
            reward_0 = 1 / rewards[0]

        if reward_1 != 1000000:
            reward_1 = 1 / rewards[1]

        if reward_2 != 1000000:
            reward_2 = 1 / rewards[2]

        if reward_3 != 1000000:
            reward_3 = 1 / rewards[3]

        if reward_4 != 1000000:
            reward_4 = rewards[4]


        rewards = [reward_0, reward_1, reward_2, reward_3, reward_4, reward_5]
        return rewards


    def plan(self, episode):
        
        # Dataset initialization
        if episode == 1:
            df = pd.DataFrame(columns=self.columns)
            df.to_csv(self.DATASET_FILE, index=False)

        # Model update for the first time or every n episodes
        if episode == self.START_PLANNING_AT or episode % self.UPDATE_MODEL_EVERY == 0:
            with open(self.DATASET_FILE, "a", newline="") as f:
                writer = csv.writer(f)
                writer.writerows(self.buffer_values)
            self.buffer_values = []
            df_t = pd.read_csv(self.DATASET_FILE)

            self.model = init_model(df_t, self.DOT_FILE)
            
        # START OF PLANNING PHASE
        if episode >= self.START_PLANNING_AT and episode % self.PLAN_AFTER == 0:

            simulated = []
            for simulation in range(self.SIMULATIONS):
            
                # Select random initial state from observations
                rand_index = random.randrange(len(self.all_values))
                while rand_index in simulated and len(simulated)<len(self.all_values):
                    rand_index = random.randrange(len(self.all_values))
                simulated.append(rand_index)
                plan_transition = self.all_values[rand_index]

                for step in range(self.ROLLOUT_STEPS):
                    planned_actions = []

                    for breadth_lvl in range(self.ACTIONS_TO_PLAN):
                        # print("Planned transition # " + str(simulation) + " - ACTION #" +  str(breadth_lvl))

                        # extract variables names
                        if step <= 1:
                            state_var = self.columns[step*(self.STATE_VARIABLES+1):step*(self.STATE_VARIABLES+1)+self.STATE_VARIABLES]
                            state_var.append(self.columns[step*(self.STATE_VARIABLES+1)+self.STATE_VARIABLES+step])
                            next_state_var = self.columns[step*(self.STATE_VARIABLES+1)+self.STATE_VARIABLES+1+step:step*(self.STATE_VARIABLES+1)+2*self.STATE_VARIABLES+1+step]
                            reward_var = self.columns[step*(self.STATE_VARIABLES+1)+2*self.STATE_VARIABLES+1+step:step*(self.STATE_VARIABLES+1)+2*self.STATE_VARIABLES+1+step+self.REWARDS_VARIABLES]

                        # extract start state from entire saved transition
                        plan_continue_state = []
                        observed_action = None
                        for variable in state_var:
                            if 'O' in variable:
                                plan_continue_state.append(plan_transition[self.columns.index(variable)])
                            if 'A' in variable:
                                observed_action = plan_transition[self.columns.index(variable)]

                        # select action to perform
                        plan_action = np.random.randint(0, self.ACTION_SPACE)
                        while (plan_action in planned_actions) or (plan_action == observed_action):
                            plan_action = np.random.randint(0, self.ACTION_SPACE)


                        # perform COUNTERFACTUAL
                        sim_samples = counterfactual(self.model, self.columns, plan_transition, state_var[len(state_var)-1], plan_action)
                        # extract results of query
                        sim_samples = sim_samples[self.columns]
                        plan_continue_next_state = list(sim_samples[next_state_var].mean())
                        plan_rewards = sim_samples[reward_var].mean()

                        # apply reward transformation
                        updated_plan_rewards = self.update_plan_rewards(plan_rewards)

                        # # discretize state and feed save in buffer
                        discrete_plan_continue_state = self.get_discrete_state(plan_continue_state)
                        discrete_plan_continue_next_state = self.get_discrete_state(plan_continue_next_state)
                      
                        self.obj_list.learn(discrete_plan_continue_state, plan_action, updated_plan_rewards, discrete_plan_continue_next_state)


    def run(self, number_of_actions, obj_thresholds, timer):
        budget_finished = False
        start_time = time.time()
        end_time = None

        episode = 0
        while not budget_finished:
            print("RUNNING EPISODE: " + str(episode))
            episode += 1

            if end_time is None:
                self.epsilon = 1
            else:
                paused_time = timer.get_paused_time()
                time_in_minutes = (end_time - paused_time - start_time)/60
                print(time_in_minutes)
                if time_in_minutes >= 48: #20 % of 240 minutes
                    self.epsilon = 0.1
                else:
                    self.epsilon = (54 - time_in_minutes)/54
            if self.epsilon <= 0.1:
                self.epsilon = 0.1

            tc = Test_Case()
            s = None
            a = None
            rewards = []
            self.remove_unnecessary_files()
            self.env.reset()
            actions_taken = 0
            stopping_condition = False

            logger = self.get_logger(timer)

            action_values = []
            action_count = 0

            while not stopping_condition and not self.terminate():
                s = self.env.observe()
                discrete_s = self.get_discrete_state(s)

                # a = self.choose_action(s, rewards)
                a = self.choose_action(discrete_s, rewards)

                if action_count == 0:
                    for value in s:  
                        action_values.append(value)
                action_values.append(a)

                rewards, next_state, plan_rewards = self.env.perform(a)
                
                for value in next_state:  
                    action_values.append(value)
                for value in plan_rewards:
                    action_values.append(value)

                if action_count == self.ROLLOUT_STEPS-1:
                    self.buffer_values.append(action_values)
                    self.all_values.append(action_values)
                    action_values = []
                    action_count = 0
                else:
                    action_count += 1

                logger.info(str(discrete_s) + "#" + str(a) + "#" + str(rewards))
                # logger.info(str(s) + "#" + str(a) + "#" + str(rewards))

                self.obj_list.learn(discrete_s, a, rewards, next_state)
                # self.obj_list.learn(s, a, rewards, next_state)
                tc.update([discrete_s, a])
                # tc.update([s, a])

                actions_taken = actions_taken + 1
                if actions_taken > number_of_actions:
                    stopping_condition = True
                print("Action: " + str(a) + " Total Count: " + str(actions_taken))
                for index in range(self.total_objs):
                    if rewards[index] > obj_thresholds[index]:
                        self.obj_list.remove_from_uncovered(index)
                        if tc.get_reward() > -1:  # one test case satisfying multiple objectives
                            tc = copy.deepcopy(tc)
                        tc.update_reward(rewards[index])
                        self.archive.update(tc, index)
            if rewards[4] > 0.05:
                if check_valid():
                    self.obj_list.remove_from_uncovered(4)
                    rewards[4] = 1000000
                    tc.update_reward(rewards[4])
                    self.archive.update(tc, 4)
                    logger.info(str(discrete_s) + "#" + str(a) + "#" + str(rewards))
                    # logger.info(str(s) + "#" + str(a) + "#" + str(rewards))
            
            print("I Waiting for planning to finish...")
            timer.pause()
            self.plan(episode)
            timer.resume()
            print("I Planning finished...")

            end_time = time.time()
