

class Objective_list:
    def __init__(self):
        self.uncovered_objective_list = []
        self.covered_objective_list = []


    def number_of_objs(self):
        return len (self.uncovered_objective_list)+ len(self.covered_objective_list)

    def get_uncovered_objective_list(self):
        return self.uncovered_objective_list

    def remove_from_uncovered(self, indx):
        obj_to_remove = None
        for obj in self.uncovered_objective_list:
            if obj.obj_no == indx:
                obj_to_remove = obj
                break
        if obj_to_remove is not None:
            if obj in self.uncovered_objective_list:
                self.uncovered_objective_list.remove(obj)
            if obj not in self.covered_objective_list:
                self.covered_objective_list.append(obj)

    def get_covered_objective_list(self):
        return self.covered_objective_list

    def add_to_list(self, obj):
        self.uncovered_objective_list.append(obj)

    def get_all_uncovered(self):
        uncovered = []
        for u in self.uncovered_objective_list:
            uncovered.append(u.obj_no)
        return uncovered

    def add_to_covered(self, obj_no):
        for u in self.uncovered_objective_list:
            if u.obj_no == obj_no:
                self.covered_objective_list.append(u)
                self.uncovered_objective_list.remove(u)

    def choose_action(self, q_table_no, observation):
        for u in self.uncovered_objective_list:
            if u.get_obj_no() == q_table_no:
                return u.get_action(observation)

    def learn(self, state, action, reward, next_state):
        for u in self.uncovered_objective_list:
            u.learn(state, action, reward[u.get_obj_no()], next_state)
        # for o in self.covered_objective_list:
        #     o.learn_q_table(state, action, reward[o.get_obj_no()], next_state)

    def memorize(self, state, action, reward, next_state,done):
        for u in self.uncovered_objective_list:
            u.memorize(state, action, reward[u.get_obj_no()], next_state,done)

    def memorize_plan(self, state, action, reward, next_state,done):
        for u in self.uncovered_objective_list:
            u.memorize_plan(state, action, reward, next_state,done)

    def update_target(self):
        for u in self.uncovered_objective_list:
            u.update_target() 

    def replay(self):
        for u in self.uncovered_objective_list:
            u.replay()

    def replay_plan(self):
        for u in self.uncovered_objective_list:
            u.replay_plan() 

    def save_models(self,descr):
        for u in self.uncovered_objective_list:
            u.save_model(descr)
        for u in self.covered_objective_list:
            u.save_model(descr)

    def load_models(self,descr):
        for u in self.uncovered_objective_list:
            u.load_model(descr)