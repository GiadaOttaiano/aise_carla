import copy
import os.path
import random
import numpy as np
import pandas as pd

from objective_sac import ObjectiveSAC
from objective_list import Objective_list
from environment import Environment
import logging
from datetime import datetime
from config import abs_path

class RL_SAC:
    def __init__(self, objectives,budget_in_minutes):
        self.obj_list = Objective_list()
        
        self.action_count = 0
        self.total_objs = objectives

        self.STATE_VARIABLES = 23
        self.REWARDS_VARIABLES = 6
        self.ACTION_SPACE = 19

        self.USE_MEMORY = True
        self.reward_decay = 0.99 # gamma
        self.batch_size =  32
        self.buffer_size =  2000
        self.gradient_steps = 1
        self.target_update_interval=100
        self.replay_interval=1
        self.objective_number = objectives

        self._q_learning_rate = 3e-4
        self._p_learning_rate = 3e-4
        self._target_entropy_scale = 0.89
        self._autotune_alpha = True
        self._alpha = 0.2
        self._tau = 1.0
        self.learning_starts = 1000

        self.actions = list(range(self.ACTION_SPACE))

        self.max_actions_count = 2500
        self.env = Environment(objectives,self.max_actions_count)

        # for i in range(objectives):
        self.obj_list.add_to_list(ObjectiveSAC(self.objective_number, self.ACTION_SPACE, self.STATE_VARIABLES, self._q_learning_rate, self._p_learning_rate, self._target_entropy_scale, self._autotune_alpha, self._alpha, self._tau, self.reward_decay, self.batch_size, self.buffer_size, self.gradient_steps))


    def get_obj_list(self):
        return self.obj_list

    def get_env(self):
        return self.env

    def get_actions(self):
        return self.actions

    def get_archive(self):
        return self.archive

    def choose_action(self, observation):
        return self.obj_list.choose_action(self.objective_number, observation)

    def write_file(self, fn):
        file = open(abs_path+'RL-comps/' + fn + ".txt", 'w')
        file.write("aaa")
        file.close()

    def terminate(self):
        check_file = abs_path+"RL-comps/terminate.txt"
        if os.path.exists(check_file):
            return True
        return False

    def remove_unnecessary_files(self):
        temp_terminate_file = abs_path+"RL-comps/terminate.txt"
        if os.path.exists(temp_terminate_file):
            os.remove(temp_terminate_file)
        temp_terminate_file = abs_path+"RL-comps/start_RL.txt"
        if os.path.exists(temp_terminate_file):
            os.remove(temp_terminate_file)

    def get_logger(self):
        logger = logging.getLogger()

        now = datetime.now()
        log_file = 'output/SAC/' + str(now) + '_transfuser.log'
        logging.basicConfig(filename=log_file,
                            format='%(asctime)s %(message)s')

        logger.setLevel(logging.DEBUG)
        logger.info("Started")
        return logger

    def run(self):

        steps_count = 0
        steps_count_2 = 0
        steps_count_tot = 0

        while True:

            # environment initialization
            state = None
            action = None
            rewards = []
            self.remove_unnecessary_files()

            reset_ok = True
            try:
                state = self.env.reset()
                state_shaped = np.reshape(state, [1, self.STATE_VARIABLES])
            except (Exception) as e:
                reset_ok = False
                print(e)  

            if reset_ok:
                action_count = 0
                stopping_condition = False

                logger = self.get_logger()

                while not stopping_condition:
                    steps_count += 1
                    steps_count_2 += 1
                    steps_count_tot += 1

                    # observe
                    state = self.env.observe()
                    state_shaped = np.reshape(state, [1, self.STATE_VARIABLES])
                    
                    # select action
                    if steps_count_tot <= self.learning_starts:
                        print("Selecting random action..")
                        action = random.randint(0, len(self.actions)-1)
                    else:
                        action = self.choose_action(state_shaped)
                    action_count = action_count+1

                    # perform action
                    next_state, rewards, done = self.env.perform(action)
                    next_state_shaped = np.reshape(next_state, [1, self.STATE_VARIABLES])

                    print("Action: " + str(action) + " - Count: " + str(action_count) + " - Reward: " + str(rewards[1]))                    

                    # check stopping condition
                    if done == 1:
                        stopping_condition = True

                    if self.USE_MEMORY:
                        self.obj_list.memorize(state_shaped, action, rewards, next_state_shaped, done)

                        if steps_count_tot > self.batch_size and steps_count_2 >= self.replay_interval and steps_count_tot >= self.learning_starts:
                            steps_count_2 = 0
                            self.obj_list.replay()
                    else:
                        # update policy
                        self.obj_list.learn(state_shaped, action, rewards, next_state_shaped, done)
                    
                    if steps_count >= self.target_update_interval:
                        steps_count = 0
                        self.obj_list.update_target()

                    logger.info(str(state) + "#" + str(action) + "#" + str(rewards))