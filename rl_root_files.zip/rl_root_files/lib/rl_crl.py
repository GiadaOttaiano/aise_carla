import os.path
import random
import numpy as np
import pandas as pd

from objective import Objective
from objective_list import Objective_list
from environment import Environment
import logging
from datetime import datetime
import time
from config import abs_path

import csv
from crl_query import *
from crl_util import *
from logger_formatter import SubtractSecondsLogger


class RL_CRL:
    def __init__(self, target_objective, budget_in_minutes):

        # static variables
        self.STATE_VARIABLES = 23
        self.REWARDS_VARIABLES = 6
        self.PLAN_REWARDS_VARIABLES = 1
        # MULTI ACTION 19 (18 actions +1 do nothing)
        # NO MULTI ACTION 7 (6 actions +1 do nothing)
        self.ACTION_SPACE = 19
        self.budget = budget_in_minutes
        self.epsilon_budget = self.budget*20/100 #20% of entire budget
        self.epsilon_budget_offset = int((0.1/0.9*self.epsilon_budget)+1)

        # rl variables
        self.USE_MEMORY = True
        self.learning_rate = 1e-2
        self.reward_decay = 0.9 # gamma
        self.batch_size = 32
        self.buffer_size =  1500
        self.gradient_steps = 1
        self.target_update_interval=100
        self.replay_interval=1
        self.objective_number = target_objective

        # other variables
        self.TRAIN = True
        self.FINE_TUNE = False
        # CRL_2024-05-29 09:48:18.449641 - CRL_2024-05-29 14:22:34.258252 - CRL_2024-05-30 18:31:23.582009 - CRL_2024-05-30 23:04:38.936578
        self.target_model_descr = "CRL_2024-05-30 23:04:38.936578"
        # dataset_2024-05-29 09:48:18.449641 - dataset_2024-05-29 14:22:34.258252 - dataset_2024-05-30 18:31:23.582009 - dataset_2024-05-30 23:04:38.936578
        self.fine_tune_dataset = "./crl_data/dataset_2024-05-30 23:04:38.936578.csv"
        self.max_actions_count = 2500
        self.actions = list(range(self.ACTION_SPACE))

        # initialization
        self.obj_list = Objective_list()
        self.env = Environment(target_objective,self.max_actions_count)

        # for i in range(objectives):
        self.obj_list.add_to_list(Objective(self.objective_number, self.ACTION_SPACE, self.STATE_VARIABLES, self.learning_rate, self.reward_decay, self.batch_size, self.buffer_size, self.gradient_steps))

        if not self.TRAIN:
            self.obj_list.load_models(self.target_model_descr)

        # logger variables for timer usage
        self.LOG_INST = False
        self.log_date = None

        ################# CRL VARIABLES #################
        self.model = None
        
        # NRS - plan after n real episodes
        self.PLAN_AFTER = 1
        # PE - number of planning simulations
        self.SIMULATIONS = 40
        # PA-B - breadth of the simulation (how many actions to plan on)
        self.ACTIONS_TO_PLAN = 1
        self.ACTIONS_RANDOM = True
        # PA-D - depth of the simulation (rollout length)
        self.ROLLOUT_STEPS = 1

        # self.USE_DIFFERENT_BUFFER = False
        self.MEASURE_TIME = False
        
        # Fixed
        self.START_PLANNING_AT = 1
        self.UPDATE_MODEL_EVERY = 1

        self.DATASET_FILE = "./crl_data/dataset.csv"
        self.DOT_FILE = "./crl_data/causal_graph.dot"
        self.IMG_FILE = "./crl_data/causal_graph.svg"

        self.columns = []
        self.initialize_causal_graph()
        self.buffer_values = []
        self.all_values = []

    def initialize_causal_graph(self):
        columns = []

        for timestep in range(self.ROLLOUT_STEPS+1):
            for observation in range(self.STATE_VARIABLES):
                columns.append("O"+str(observation)+"_"+str(timestep))

            if timestep > 0:
                for obj_reward in range(self.PLAN_REWARDS_VARIABLES):
                    columns.append("R"+str(obj_reward)+"_"+str(timestep-1))

            if timestep < self.ROLLOUT_STEPS:
                columns.append("A_"+str(timestep))

        # print(str(columns))
        print("I Generating graph")
        generate_dot(self.STATE_VARIABLES,self.PLAN_REWARDS_VARIABLES, self.ROLLOUT_STEPS+1, self.DOT_FILE)

        self.columns = columns
        return 0

    def get_obj_list(self):
        return self.obj_list

    def get_env(self):
        return self.env

    def get_actions(self):
        return self.actions

    def choose_action(self, observation):
        return self.obj_list.choose_action(self.objective_number, observation)

    def learn(self, state, action, reward, next_state):
        self.obj_list.learn(state, action, reward, next_state)

    def write_file(self, fn):
        file = open(abs_path+'RL-comps/' + fn + ".txt", 'w')
        file.write("aaa")
        file.close()

    def remove_unnecessary_files(self):
        temp_terminate_file = abs_path+"RL-comps/terminate.txt"
        if os.path.exists(temp_terminate_file):
            os.remove(temp_terminate_file)
        temp_terminate_file = abs_path+"RL-comps/start_RL.txt"
        if os.path.exists(temp_terminate_file):
            os.remove(temp_terminate_file)


    def get_logger(self, timer):
        logger = SubtractSecondsLogger("logger_1",subtract_seconds=timer.get_paused_time())
        if not self.LOG_INST:
            now = datetime.now()
            self.log_date = str(now)
            self.LOG_INST = True
        log_file = 'output/CRL/' + str(self.log_date) + '_transfuser.log'
        # Configure the logger to log to file
        file_handler = logging.FileHandler(log_file, mode="a")
        file_handler.setLevel(logging.DEBUG)
        formatter = logging.Formatter('%(asctime)s %(message)s')
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
        logger.info("Started")

        return logger

    # def get_logger(self):
    #     logger = logging.getLogger()

    #     now = datetime.now()
    #     log_file = 'output/CRL/' + str(now) + '_transfuser.log'
    #     logging.basicConfig(filename=log_file,
    #                         format='%(asctime)s %(message)s')

    #     logger.setLevel(logging.DEBUG)
    #     logger.info("Started")
    #     return logger


    def plan(self, episode):
        
        # Dataset initialization
        if episode == 1 and not self.FINE_TUNE:
            df = pd.DataFrame(columns=self.columns)
            df.to_csv(self.DATASET_FILE, index=False)

        # Model update for the first time or every n episodes
        if episode == self.START_PLANNING_AT or episode % self.UPDATE_MODEL_EVERY == 0:
            with open(self.DATASET_FILE, "a", newline="") as f:
                writer = csv.writer(f)
                writer.writerows(self.buffer_values)
            self.buffer_values = []
            df_t = pd.read_csv(self.DATASET_FILE)

            self.model = init_model(df_t, self.DOT_FILE)
            
        # START OF PLANNING PHASE
        if episode >= self.START_PLANNING_AT and episode % self.PLAN_AFTER == 0:

            simulated = []
            for simulation in range(self.SIMULATIONS):
            
                # Select random initial state from observations
                rand_index = random.randrange(len(self.all_values))
                while rand_index in simulated and len(simulated)<len(self.all_values):
                    rand_index = random.randrange(len(self.all_values))
                simulated.append(rand_index)
                plan_transition = self.all_values[rand_index]

                for step in range(self.ROLLOUT_STEPS):
                    planned_actions = []

                    for breadth_lvl in range(self.ACTIONS_TO_PLAN):
                        # print("Planned transition # " + str(simulation) + " - ACTION #" +  str(breadth_lvl))

                        # extract variables names
                        if step <= 1:
                            state_var = self.columns[step*(self.STATE_VARIABLES+1):step*(self.STATE_VARIABLES+1)+self.STATE_VARIABLES]
                            state_var.append(self.columns[step*(self.STATE_VARIABLES+1)+self.STATE_VARIABLES+step])
                            next_state_var = self.columns[step*(self.STATE_VARIABLES+1)+self.STATE_VARIABLES+1+step:step*(self.STATE_VARIABLES+1)+2*self.STATE_VARIABLES+1+step]
                            reward_var = self.columns[step*(self.STATE_VARIABLES+1)+2*self.STATE_VARIABLES+1+step:step*(self.STATE_VARIABLES+1)+2*self.STATE_VARIABLES+1+step+self.PLAN_REWARDS_VARIABLES]

                        # extract start state from entire saved transition
                        plan_state = []
                        observed_action = None
                        for variable in state_var:
                            if 'O' in variable:
                                plan_state.append(plan_transition[self.columns.index(variable)])
                            if 'A' in variable:
                                observed_action = plan_transition[self.columns.index(variable)]

                        # select action to perform
                        plan_action = np.random.randint(0, self.ACTION_SPACE)
                        while (plan_action in planned_actions) or (plan_action == observed_action):
                            plan_action = np.random.randint(0, self.ACTION_SPACE)


                        # perform COUNTERFACTUAL
                        sim_samples = counterfactual(self.model, self.columns, plan_transition, state_var[len(state_var)-1], plan_action)
                        # extract results of query
                        sim_samples = sim_samples[self.columns]
                        plan_next_state = list(sim_samples[next_state_var].mean())
                        plan_reward = sim_samples[reward_var].mean().to_list()[0]

                        plan_state = np.reshape(plan_state, [1, self.STATE_VARIABLES])
                        plan_next_state = np.reshape(plan_next_state, [1, self.STATE_VARIABLES])

                        # print("--------------------------")
                        # print("Observed state: " + str(plan_state))
                        # print("Planning action: " + str(plan_action))
                        # print("Planning next state: " + str(plan_next_state))
                        # print("Planning reward: " + str(plan_reward))

                        # REWARD IMPLEMENTATION
                        if plan_reward >= 1:
                            plan_reward = 10
                        # elif plan_reward < 0.2:
                        #     plan_reward = -1
                        elif plan_reward < 0:
                            plan_reward = 0
                        # print("Planning reward after adjust: " + str(plan_reward))

                        plan_done = 0
                        self.obj_list.memorize_plan(plan_state, plan_action, plan_reward, plan_next_state, plan_done)

                        self.steps_count_target += 1
                        self.steps_count_tot += 1
                        if self.steps_count_tot > self.batch_size:
                            self.obj_list.replay()
                        if self.steps_count_target >= self.target_update_interval:
                            self.steps_count_target = 0
                            self.obj_list.update_target()

    def run(self,timer):
        
        if self.TRAIN or self.FINE_TUNE:
            date_time = datetime.now()
            self.DATASET_FILE = "./crl_data/dataset_"+str(date_time)+".csv"
            if self.FINE_TUNE:
                self.DATASET_FILE = self.fine_tune_dataset
            start_time = time.time()
            end_time = None
        self.steps_count_target = 0
        self.steps_count_tot = 0

        USE_TIMER = True
        if timer == None:
            USE_TIMER = False
            

        episode = 0
        while True:
            episode += 1

            if self.TRAIN:
                # epsilon decaying
                if end_time is None:
                    epsilon = 1
                else:
                    if USE_TIMER:
                        paused_time = timer.get_paused_time()
                        time_in_minutes = (end_time - paused_time - start_time)/60
                    else:
                        time_in_minutes = (end_time - start_time)/60
                    print(time_in_minutes)
                    if time_in_minutes >= self.epsilon_budget: #20 % of 240 minutes
                        epsilon = 0.1
                    else:
                        epsilon = (self.epsilon_budget+self.epsilon_budget_offset - time_in_minutes)/(self.epsilon_budget+self.epsilon_budget_offset)
                if epsilon <= 0.1:
                    epsilon = 0.1
            else:
                epsilon = 0.1

            # initialization
            state = None
            action = None
            rewards = []

            self.remove_unnecessary_files()
            if USE_TIMER:
                logger = self.get_logger(timer)
            else:
                logger = self.get_logger()

            reset_ok = True
            try:
                state = self.env.reset()
                state_shaped = np.reshape(state, [1, self.STATE_VARIABLES])
            except (Exception) as e:
                reset_ok = False
                print(e)                    

            if reset_ok:
                action_values = []
                action_count = 0
                action_count_rollout = 0

                stopping_condition = False
                done = 0
                while not stopping_condition:
                    # counters increment
                    self.steps_count_target += 1
                    self.steps_count_tot += 1
                    
                    # select action
                    print("Epsilon: "+ str(epsilon))
                    random_value = np.random.uniform()
                    if random_value < epsilon:
                        print("I Selecting random action..")
                        action = random.randint(0, len(self.actions)-1)
                    else:
                        action = self.choose_action(state_shaped)

                    # save state-action in temp transition
                    if action_count_rollout == 0:
                        for value in state:  
                            action_values.append(value)
                    action_values.append(action)

                    action_count = action_count+1
                        
                    # perform action
                    next_state, rewards, done = self.env.perform(action)

                    print("Action: " + str(action) + " - Count: " + str(action_count) + " - Reward: " + str(rewards[1]))

                    for value in next_state:  
                        action_values.append(value)
                    
                    plan_reward = rewards[self.objective_number]
                    if plan_reward >= 10:
                        plan_reward = 1
                    action_values.append(plan_reward)

                    if action_count_rollout == self.ROLLOUT_STEPS-1:
                        self.buffer_values.append(action_values)
                        self.all_values.append(action_values)
                        action_values = []
                        action_count = 0
                    else:
                        action_count_rollout += 1

                    next_state_shaped = np.reshape(next_state, [1, self.STATE_VARIABLES])
                    
                    # check stopping condition
                    if done == 1:
                        stopping_condition = True

                    if self.TRAIN or self.FINE_TUNE:
                        # train agent
                        if self.USE_MEMORY:
                            self.obj_list.memorize(state_shaped, action, rewards, next_state_shaped, done)
                            if self.steps_count_tot > self.batch_size:
                                self.obj_list.replay()
                        else:
                            self.obj_list.learn(state_shaped, action, rewards, next_state_shaped)
                        
                        # update target model
                        if self.steps_count_target >= self.target_update_interval:
                            self.steps_count_target = 0
                            self.obj_list.update_target()

                    # log info
                    logger.info(str(state) + "#" + str(action) + "#" + str(rewards))
                    
                    # set starting state
                    state = next_state
                    state_shaped = next_state_shaped

                self.env.stop()

                print("I Waiting for planning to finish...")
                if USE_TIMER:
                    timer.pause()
                self.plan(episode)
                if USE_TIMER:
                    timer.resume()
                print("I Planning finished...")         

                if self.TRAIN:
                    self.obj_list.save_models("CRL_"+str(date_time))
                    end_time = time.time()
                elif self.FINE_TUNE:
                    self.obj_list.save_models("CRL_finetuned_"+str(date_time))  