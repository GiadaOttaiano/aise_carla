import subprocess
import time
import os
import socket
import errno
import docker
import multiprocessing

import psutil
from config import abs_path

from collections import deque
from datetime import datetime
import psutil
from pynvml import nvmlInit, nvmlDeviceGetMemoryInfo, nvmlDeviceGetHandleByIndex, nvmlShutdown
import time


class Environment:

    def __init__(self, objective_number, max_actions_count):
        self.objective_number = objective_number
        self.max_actions_count = max_actions_count
        self.performed_actions = 0
        self.latest_state = None
        self.latest_rewards = None

        self.PENALTY = False
        self.penalty_value = -10
        self.COLLISION_REWARD = False
        self.collision_rew_value = 100

        # #MEMORY
        # self.memory_log = deque(maxlen=500)
        # try:
        #     nvmlInit()
        #     print(f"GPU Initialization Success")
        # except Exception as e:
        #     print(f"GPU Initialization Failed: {e}")

############################################################### 
    # def _get_memory_info(self):

    #     """Retrieve central memory (RAM) info."""
    #     memory_info = psutil.virtual_memory()

    #     try:
    #         handle = nvmlDeviceGetHandleByIndex(0)
    #         mem_info = nvmlDeviceGetMemoryInfo(handle)
    #         return {
    #             "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    #             "total_memory_gb": memory_info.total / (1024 ** 3),
    #             "available_memory_gb": memory_info.available / (1024 ** 3),
    #             "used_memory_gb": memory_info.used / (1024 ** 3),
    #             "memory_usage_percent": memory_info.percent,
    #             "total_gpu_memory_gb": mem_info.total / (1024 ** 3),
    #             "used_gpu_memory_gb": mem_info.used / (1024 ** 3),
    #             "free_gpu_memory_gb": mem_info.free / (1024 ** 3),
    #         }
    #     except Exception as e:
    #         return {"error": f"GPU query failed: {e}"}

    # def _queue_memory_usage(self):
    #     """Log memory usage periodically."""
    #     # Collect memory info
    #     memories_info = self._get_memory_info()

    #     # Append to log
    #     self.memory_log.append({
    #         "memories": memories_info
    #         })

    # def _write_memlog_to_file(self):
    #     """Write the memory log to a file."""
    #     log_file = "memory_logs/memory_log_"+str(datetime.now())+".txt"
    #     try:
    #         with open(log_file, "w") as f:
    #             for entry in self.memory_log:
    #                 f.write(f"{entry}\n")
    #     except Exception as e:
    #         print(f"Failed to write memory log: {e}")

############################################################### 

    def run_command(self, cmd):
        process = subprocess.Popen(cmd,
                                   stdout=subprocess.PIPE,
                                   universal_newlines=True, shell=True)

    def run(self):
        os.system('cd carla_garage && ./leaderboard/scripts/run_evaluation.sh')

    def run_sim(self):
        # cmd = ['./carla_garage/carla/CarlaUE4.sh -RenderOffScreen']
        # cmd = ['./sim/CarlaUE4.sh -RenderOffScreen']
        cmd = ['./sim/CarlaUE4.sh -RenderOffScreen -prefernvidia']
        # cmd = ['./sim/CarlaUE4.sh -prefernvidia']
        # cmd = ['./carla_garage/carla/CarlaUE4.sh']
        self.run_command(cmd)
        
        # self.start_carla_container(container_name='carla-container', headless=True)
        
        print("Simulator runnning")

    def observe(self):
        while not os.path.exists('RL-comps/reward.txt'):
            # print('I waiting for state')
            time.sleep(0.001)

        state = open('RL-comps/reward.txt').read().split("#")[1]

        state = [float(x) for x in state.split(",")]

        return state

    def reset(self):
        try:
            
            self.performed_actions = 0

            for proc in psutil.process_iter():
                try:
                    if "carla".lower() in proc.name().lower():
                        print(proc.pid)
                        print(proc.name())
                        proc.kill()
                        print("KILLED CARLA")
                    if "run_evaluation".lower() in proc.name().lower():
                        proc.kill()
                except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess) as e:
                    print("EXCEPTION RESET: " + str(e))
                    pass

            self.kill_processes_on_port(port=2000)
            time.sleep(5)
            self.kill_processes_on_port(port=8000)

            # os.system("kill -9 `lsof -t -i:2000`")
            # os.system("kill -9 `lsof -t -i:8000`")
            time.sleep(5)

            # self.stop_carla_container(container_name='carla-container')

            p_sim = multiprocessing.Process(target=self.run_sim, name="run_sim")
            p_sim.start()
            time.sleep(5)

            p = multiprocessing.Process(target=self.run, name="run")
            p.start()
            time.sleep(5)

            temp_terminate_file = abs_path+"RL-comps/start_RL.txt"
            countwaiting = 0
            while not os.path.exists(temp_terminate_file):
                print('waiting for transfuserpp to run')
                
                # MEMORY GET
                # self._queue_memory_usage()
                
                time.sleep(1)
                countwaiting = countwaiting + 1
                if countwaiting > 60:
                    # MEMORY WRITE
                    # self._write_memlog_to_file()
                    self.reset()
                    return

                # # MEMORY WRITE (TOREMOVE)
                # self._write_memlog_to_file()
                
        except Exception as e:
            print("GENERIC EXCEPTION: " + str(e))

        return self.observe()
    
    def stop(self):
        
        for proc in psutil.process_iter():
            try:
                if "carla".lower() in proc.name().lower():
                    proc.kill()
                if "run_evaluation".lower() in proc.name().lower():
                    proc.kill()
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                pass
        # os.system("kill -9 `lsof -t -i:2000`")
        # os.system("kill -9 `lsof -t -i:8000`")

        self.kill_processes_on_port(port=2000)
        time.sleep(5)
        self.kill_processes_on_port(port=8000)

        # self.stop_carla_container(container_name='carla-container')
        
        
    def terminate(self):
        check_file = abs_path+"RL-comps/terminate.txt"
        if os.path.exists(check_file):
            return True
        return False


    def perform(self, action):

        self.performed_actions += 1

        rwa = abs_path+'RL-comps/reward.txt'
        if os.path.exists(rwa):
            # print('I removing reward')
            os.remove(rwa)

        action_file = open(abs_path+'RL-comps/action.txt', "w")
        action_file.write(str(action))
        action_file.close()
        # print('I creating action')

        while not os.path.exists(rwa):
            # print('I waiting for reward')
            time.sleep(0.01)
            if self.terminate():
                if self.latest_rewards[1] < 1 and self.PENALTY:
                    self.latest_rewards[1] = self.penalty_value
                return self.latest_state, self.latest_rewards, 1

        time.sleep(0.01)

        reward_content_parts = open(rwa, "r").read().split("#")
        reward_content = reward_content_parts[0]
        rewards = [float(x) for x in reward_content.split(',')]

        reward_0 = rewards[0]
        reward_1 = rewards[1]
        reward_2 = 0
        reward_3 = 0
        reward_4 = 0
        reward_5 = 0

        # if rewards[1] >= 1:
        #     reward_1 = 10
        # else:
        #     reward_1 = rewards[1]

        rewards = [reward_0, reward_1, reward_2, reward_3, reward_4, reward_5]
        next_state = reward_content_parts[1]
        next_state = [float(x) for x in next_state.split(",")]

        # done computation
        done = 0
        if self.performed_actions > self.max_actions_count or rewards[1] >= 1 or self.terminate():
            done = 1
            if rewards[1] < 1 and self.PENALTY:
                rewards[1] = self.penalty_value
            elif rewards[1] >= 1 and self.COLLISION_REWARD:
                rewards[1] = self.collision_rew_value

        self.latest_state = next_state
        self.latest_rewards = rewards

        return next_state, rewards, done
    
    @staticmethod
    def start_carla_container(container_name: str, headless: bool = True) -> None:
        client = docker.from_env()
        
        if headless:
            cmd = "/bin/bash ./CarlaUE4.sh -RenderOffScreen"
            volumes = {'/tmp/.X11-unix': {'bind': '/tmp/.X11-unix', 'mode': 'rw'}}
        else:
            cmd = "/bin/bash ./CarlaUE4.sh"
            volumes = {}

        client.containers.run(
            image='carlasim/carla:0.9.14', 
            detach=True, 
            device_requests=[docker.types.DeviceRequest(count=-1, capabilities=[['gpu']])],
            privileged=True, 
            tty=True, 
            stdin_open=True,
            name=container_name,
            network_mode="host",
            volumes=volumes,
            command=cmd
        )

    @staticmethod
    def kill_processes_on_port(port: int) -> None:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("127.0.0.1", port))
            except socket.error as e:
                if e.errno == errno.EADDRINUSE:
                    print(f"Killing process listening on port {port}")
                    os.system(f"kill -9 `lsof -t -i:{port}`")
                else:
                    raise e

    def stop_carla_container(self, container_name: str) -> None:
        client = docker.from_env()
        try:
            container = client.containers.get(container_name)        
            container.stop()
            container.remove()
        except docker.errors.NotFound:
            print(f"Container {container_name} not found")

        self.kill_processes_on_port(port=2000)
        time.sleep(5)
        self.kill_processes_on_port(port=8000)

