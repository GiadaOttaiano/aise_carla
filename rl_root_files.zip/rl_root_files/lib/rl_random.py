import os.path
import random
import numpy as np
import pandas as pd

from environment import Environment
import logging
from datetime import datetime
from config import abs_path

class RANDOM:
    def __init__(self, target_objective):

        # static variables
        # MULTI ACTION 19 (18 actions +1 do nothing)
        # NO MULTI ACTION 7 (6 actions +1 do nothing)
        self.ACTION_SPACE = 19

        # other variables
        self.max_actions_count = 2500
        self.actions = list(range(self.ACTION_SPACE))

        # initialization
        self.env = Environment(target_objective,self.max_actions_count)


    def get_obj_list(self):
        return self.obj_list

    def get_env(self):
        return self.env

    def get_actions(self):
        return self.actions

    def choose_action(self, observation):
        return self.obj_list.choose_action(self.objective_number, observation)

    def learn(self, state, action, reward, next_state):
        self.obj_list.learn(state, action, reward, next_state)

    def write_file(self, fn):
        file = open(abs_path+'RL-comps/' + fn + ".txt", 'w')
        file.write("aaa")
        file.close()

    def remove_unnecessary_files(self):
        temp_terminate_file = abs_path+"RL-comps/terminate.txt"
        if os.path.exists(temp_terminate_file):
            os.remove(temp_terminate_file)
        temp_terminate_file = abs_path+"RL-comps/start_RL.txt"
        if os.path.exists(temp_terminate_file):
            os.remove(temp_terminate_file)

    def get_logger(self):
        logger = logging.getLogger()

        now = datetime.now()
        log_file = 'output/RANDOM/' + str(now) + '_transfuser.log'
        logging.basicConfig(filename=log_file,
                            format='%(asctime)s %(message)s')

        logger.setLevel(logging.DEBUG)
        logger.info("Started")
        return logger

    def run(self):

        while True:
            # initialization
            action = None
            rewards = []
            self.remove_unnecessary_files()
            state = self.env.reset()
            action_count = 0
            stopping_condition = False

            logger = self.get_logger()

            done = 0
            while not stopping_condition:

                action = random.randint(0, len(self.actions)-1)

                action_count = action_count+1
                    
                # perform action
                next_state, rewards, done = self.env.perform(action)
                
                print("Action: " + str(action) + " - Count: " + str(action_count) + " - Reward: " + str(rewards[1]))

                # check stopping condition
                if done == 1:
                    stopping_condition = True

                # log info
                logger.info(str(state) + "#" + str(action) + "#" + str(rewards))

                state = next_state