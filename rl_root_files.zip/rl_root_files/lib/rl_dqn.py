import copy
import os.path
import random
import numpy as np
import pandas as pd

from objective import Objective
from objective_list import Objective_list
from environment import Environment
import logging
from datetime import datetime
import time
from config import abs_path
import math

class RL_DQN:
    def __init__(self, target_objective,budget_in_minutes):

        # static variables
        self.n_vehicles = 3
        self.STATE_VARIABLES = 3 + 5 * self.n_vehicles
        self.REWARDS_VARIABLES = 6
        # MULTI ACTION 19 (18 actions +1 do nothing)
        # NO MULTI ACTION 7 (6 actions +1 do nothing)
        self.ACTION_SPACE = 19
        self.budget = budget_in_minutes
        self.epsilon_budget = self.budget*20/100 #20% of entire budget
        self.epsilon_budget_offset = int((0.1/0.9*self.epsilon_budget)+1)

        # rl variables
        self.USE_MEMORY = True
        self.learning_rate = 1e-2
        self.reward_decay = 0.99 # gamma
        self.batch_size = 32
        self.buffer_size =  2000
        # self.buffer_size =  1500
        self.gradient_steps = 1
        self.target_update_interval=50
        # self.replay_interval=1
        self.objective_number = target_objective

        # other variables
        self.TRAIN = True
        self.FINE_TUNE = False
        # 2024-05-28 10:01:00.232006 - 2024-05-28 14:01:15.399301 - 2024-05-30 08:26:50.937365 - 2024-05-30 12:27:05.734112
        self.target_model_descr = "2024-05-30 12:27:05.734112"
        self.max_actions_count = 2500
        self.actions = list(range(self.ACTION_SPACE))

        # initialization
        self.obj_list = Objective_list()
        self.env = Environment(target_objective,self.max_actions_count)

        # for i in range(objectives):
        self.obj_list.add_to_list(Objective(self.objective_number, self.ACTION_SPACE, self.STATE_VARIABLES, self.learning_rate, self.reward_decay, self.batch_size, self.buffer_size, self.gradient_steps))

        if not self.TRAIN:
            self.obj_list.load_models(self.target_model_descr)


    def get_obj_list(self):
        return self.obj_list

    def get_env(self):
        return self.env

    def get_actions(self):
        return self.actions

    def choose_action(self, observation):
        return self.obj_list.choose_action(self.objective_number, observation)

    def learn(self, state, action, reward, next_state):
        self.obj_list.learn(state, action, reward, next_state)

    def write_file(self, fn):
        file = open(abs_path+'RL-comps/' + fn + ".txt", 'w')
        file.write("aaa")
        file.close()

    def remove_unnecessary_files(self):
        temp_terminate_file = abs_path+"RL-comps/terminate.txt"
        if os.path.exists(temp_terminate_file):
            os.remove(temp_terminate_file)
        temp_terminate_file = abs_path+"RL-comps/start_RL.txt"
        if os.path.exists(temp_terminate_file):
            os.remove(temp_terminate_file)

    def get_logger(self):
        logger = logging.getLogger()

        now = datetime.now()
        log_file = 'output/DQN/' + str(now) + '_transfuser.log'
        logging.basicConfig(filename=log_file,
                            format='%(asctime)s %(message)s')

        logger.setLevel(logging.DEBUG)
        logger.info("Started")
        return logger

    def run(self):
        
        if self.TRAIN or self.FINE_TUNE:
            date_time = datetime.now()
            start_time = time.time()
            end_time = None
        steps_count_target = 0
        steps_count_tot = 0

        while True:
            if self.TRAIN:
                # epsilon decaying
                if end_time is None:
                    epsilon = 1
                else:
                    time_in_minutes = (end_time - start_time)/60
                    print(time_in_minutes)
                    if time_in_minutes >= self.epsilon_budget: 
                        epsilon = 0.1
                    else:
                        epsilon = (self.epsilon_budget+self.epsilon_budget_offset - time_in_minutes)/(self.epsilon_budget+self.epsilon_budget_offset)
                if epsilon <= 0.1:
                    epsilon = 0.1
            else:
                epsilon = 0.1

            # initialization
            state = None
            action = None
            rewards = []
            self.remove_unnecessary_files()

            reset_ok = True
            try:
                state = self.env.reset()
                state_shaped = np.reshape(state, [1, self.STATE_VARIABLES])
            except (Exception) as e:
                reset_ok = False
                print(e)                    

            if reset_ok:

                action_count = 0
                stopping_condition = False

                logger = self.get_logger()

                done = 0
                while not stopping_condition:
                    # counters increment
                    steps_count_target += 1
                    steps_count_tot += 1
                    
                    # select action
                    print("Epsilon: "+ str(epsilon))
                    random_value = np.random.uniform()
                    if random_value < epsilon:
                        print("I Selecting random action..")
                        action = random.randint(0, len(self.actions)-1)
                    else:
                        action = self.choose_action(state_shaped)

                    action_count = action_count+1
                        
                    # perform action
                    next_state, rewards, done = self.env.perform(action)
                    next_state_shaped = np.reshape(next_state, [1, self.STATE_VARIABLES])

                    print("Action: " + str(action) + " - Count: " + str(action_count) + " - Reward: " + str(rewards[1]))

                    # check stopping condition
                    if done == 1:
                        stopping_condition = True
                    
                    if self.TRAIN or self.FINE_TUNE:
                        # train agent
                        if self.USE_MEMORY:
                            self.obj_list.memorize(state_shaped, action, rewards, next_state_shaped, done)
                            if steps_count_tot > self.batch_size:
                                self.obj_list.replay()
                        else:
                            self.obj_list.learn(state_shaped, action, rewards, next_state_shaped)
                        
                        # update target model
                        if steps_count_target >= self.target_update_interval:
                            steps_count_target = 0
                            self.obj_list.update_target()

                    # log info
                    logger.info(str(state) + "#" + str(action) + "#" + str(rewards))
                    
                    # set starting state
                    state = next_state
                    state_shaped = next_state_shaped

                if self.TRAIN:
                    self.obj_list.save_models(date_time)  
                    end_time = time.time()
                elif self.FINE_TUNE:
                    self.obj_list.save_models("_finetuned_"+str(date_time))  
