from dqn import DQN

class Objective:
    def __init__(self, _objective_number, _action_space, _state_space, _learning_rate, _reward_decay, _batch_size, _buffer_size, _gradient_steps):
        self.obj_no = _objective_number
        self.dqn = DQN(_state_space, _action_space, _learning_rate, _reward_decay, _batch_size, _buffer_size, _gradient_steps)
        self.reward = -1
        self.is_satif = False

    def get_obj_no(self):
        return self.obj_no
    
    def get_action (self, observation):
        return self.dqn.act(observation)
    
    def set_reward(self,reward):
        self.reward = reward

    def learn(self,state, action, reward, next_state):
        self.dqn.replay_single(state, action, reward, next_state)

    def replay(self):
        self.dqn.replay()
        
    def replay_plan(self):
        self.dqn.replay_plan()

    def update_target(self):
        self.dqn.update_target()

    def memorize(self,state, action, reward, next_state,done):
        self.dqn.memorize(state, action, reward, next_state,done)

    def memorize_plan(self,state, action, reward, next_state,done):
        self.dqn.memorize_plan(state, action, reward, next_state,done)

    def save_model(self,descr):
        self.dqn._save_model(self.obj_no, descr)

    def load_model(self,descr):
        self.dqn._load_model(self.obj_no, descr)

    def is_satisfied (self):
        return self.is_satif
    def set_satisfied(self):
        self.is_satif = True