import random
import numpy as np
from collections import deque
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.optimizers import Adam

# from tensorflow.compat.v1 import ConfigProto
# from tensorflow.compat.v1 import InteractiveSession
# config = ConfigProto()
# config.gpu_options.allow_growth = True
# session = InteractiveSession(config=config)

import tensorflow as tf
# config = tf.compat.v1.ConfigProto()
# config.gpu_options.allow_growth = True
# # config.gpu_options.per_process_gpu_memory_fraction = 0.2
# tf.compat.v1.keras.backend.set_session(tf.compat.v1.Session(config=config))

RUN_ON_CPU = True


class DQN:
    def __init__(self, state_size, action_size, _learning_rate, _discount, _batch_size, _buffer_size, _gradient_steps):
        self.state_size = state_size
        self.action_size = action_size
        self.memory = deque(maxlen=_buffer_size)
        self.plan_memory = deque(maxlen=_buffer_size)
        self.gamma = _discount    # discount rate
        self.learning_rate = _learning_rate
        self.batch_size = _batch_size
        self.gradient_steps = _gradient_steps
        self.model = self._build_model()
        self.model_t = self._build_target_model()
        

    def _build_model(self):
        model = Sequential()
        model.add(Dense(self.state_size*2, input_dim=self.state_size, activation='relu'))
        model.add(Dense(self.state_size*2, activation='relu'))
        model.add(Dense(self.state_size, activation='relu'))
        model.add(Dense(self.action_size, activation='linear'))
        if RUN_ON_CPU:
            with tf.device("cpu:0"):
                model.compile(loss='mse',optimizer=Adam(lr=self.learning_rate))
        else:
            model.compile(loss='mse',optimizer=Adam(lr=self.learning_rate))
        return model
    
    def _build_target_model(self):
        model = self._build_model()
        if RUN_ON_CPU:
            with tf.device("cpu:0"):
                model.set_weights(self.model.get_weights()) 
        else:
            model.set_weights(self.model.get_weights())
        return model

    def _save_model(self,obj,descr):
        self.model.save_weights("models/model_o"+str(obj)+"_"+str(descr)+".keras")

    def _load_model(self,obj,descr):
        self.model.load_weights("models/model_o"+str(obj)+"_"+str(descr)+".keras")
        self._build_target_model()

    def memorize(self, state, action, reward, next_state, done):
        self.memory.append((state, action, reward, next_state, done))

    def memorize_plan(self, state, action, reward, next_state, done):
        self.plan_memory.append((state, action, reward, next_state, done))

    def act(self, state):
        if RUN_ON_CPU:
            with tf.device("cpu:0"):
                act_values = self.model.predict(state)
        else:
            act_values = self.model.predict(state)
        return np.argmax(act_values[0])  # returns action


    def replay(self):
        for gradient_step in range(self.gradient_steps):
            minibatch = random.sample(self.memory, self.batch_size)
            state, action, reward, next_state, done = zip(*minibatch)

            state = np.vstack(state)
            next_state = np.vstack(next_state)
            action = np.array(action)
            reward = np.array(reward)[:, None]
            done = np.array(done)[:, None]

            if RUN_ON_CPU:
                with tf.device("cpu:0"):
                    current_state_q_values = self.model.predict(state)
                    next_state_q_values = self.model_t.predict(next_state)
            else:
                current_state_q_values = self.model.predict(state)
                next_state_q_values = self.model_t.predict(next_state)                

            q_learning_targets = reward + self.gamma * np.max(next_state_q_values, axis=1, keepdims=True) * (1-done)

            batch_indices = np.arange(self.batch_size)
 
            current_state_q_values[batch_indices, action] = q_learning_targets.flatten()

            if RUN_ON_CPU:
                with tf.device("cpu:0"):
                    self.model.fit(state, current_state_q_values, epochs=1, verbose=0)
            else:
                self.model.fit(state, current_state_q_values, epochs=1, verbose=0)


    def replay_plan(self):
        for gradient_step in range(self.gradient_steps):
            minibatch = random.sample(self.plan_memory, self.batch_size)
            state, action, reward, next_state, done = zip(*minibatch)

            state = np.vstack(state)
            next_state = np.vstack(next_state)
            action = np.array(action)
            reward = np.array(reward)[:, None]
            done = np.array(done)[:, None]

            if RUN_ON_CPU:
                with tf.device("cpu:0"):
                    current_state_q_values = self.model.predict(state)
                    next_state_q_values = self.model_t.predict(next_state)
            else:
                current_state_q_values = self.model.predict(state)
                next_state_q_values = self.model_t.predict(next_state)                

            q_learning_targets = reward + self.gamma * np.max(next_state_q_values, axis=1, keepdims=True) * (1-done)

            batch_indices = np.arange(self.batch_size)
 
            current_state_q_values[batch_indices, action] = q_learning_targets.flatten()

            if RUN_ON_CPU:
                with tf.device("cpu:0"):
                    self.model.fit(state, current_state_q_values, epochs=1, verbose=0)
            else:
                self.model.fit(state, current_state_q_values, epochs=1, verbose=0)

    def update_target(self):
        if RUN_ON_CPU:
            with tf.device("cpu:0"):
                self.model_t.set_weights(self.model.get_weights())
        else:
            self.model_t.set_weights(self.model.get_weights())



    def replay_single(self, state, action, reward, next_state):
        target = reward
        if reward < 1000000:
            target = (reward + self.gamma *
                        np.amax(self.model_t.predict(next_state)[0]))
            
        target_f = self.model.predict(state)
        target_f[0][action] = target
        self.model.fit(state, target_f, epochs=1, verbose=0)

    
