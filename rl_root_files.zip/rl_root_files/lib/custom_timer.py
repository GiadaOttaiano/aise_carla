import multiprocessing as mp
import time
import os


class Timer:
    def __init__(self):
        self.shared_value = mp.Value('d', 0.0)  # Shared value for the timer
        self.is_paused = mp.Value('b', False)  # Shared value for pause state
        self.pause_time = mp.Value('d', 0.0)  # Shared value for storing pause time
        self.tot_pause_time = mp.Value('d', 0.0)

    def start(self):
        self.shared_value.value = time.time()  # Set the shared value to the current time

    def elapsed_time(self):
        elapsed_time = time.time() - self.shared_value.value
        return elapsed_time
    
    def pause(self):
        if not self.is_paused.value:
            self.is_paused.value = True
            self.pause_time.value = time.time()

    def resume(self):
        if self.is_paused.value:
            self.is_paused.value = False
            elapsed_pause_time = time.time() - self.pause_time.value
            self.tot_pause_time.value += elapsed_pause_time
            self.shared_value.value += elapsed_pause_time

        filename = "planning_times.txt"
        writemode = "w"
        if os.path.exists(filename):
            writemode = "a"
        with open(filename, writemode) as writer:
            writer.writelines(str(elapsed_pause_time) + "\n")


    def stop(self):
        elapsed_time = time.time() - self.shared_value.value
        return elapsed_time
    
    def get_paused_time(self):
        return self.tot_pause_time.value

    def paused(self):
        return self.is_paused.value