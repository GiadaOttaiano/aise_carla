from qtable import QTable

class Objective:
    def __init__(self, _objective_number, _action_space, _state_space, _learning_rate, _reward_decay):
        self.obj_no = _objective_number
        self.q_table = QTable(_state_space, _action_space, _learning_rate, _reward_decay)
        self.reward = -1
        self.is_satif = False

    def get_obj_no(self):
        return self.obj_no
    
    def get_action (self, observation):
        return self.q_table.choose_action(observation)

    def learn(self,state, action, reward, next_state):
        self.q_table.learn(state, action, reward, next_state)




    def save_model(self,descr):
        self.q_table._save_model(self.obj_no, descr)
    def load_model(self,descr):
        self.q_table._load_model(self.obj_no, descr)
    def is_satisfied (self):
        return self.is_satif
    def set_satisfied(self):
        self.is_satif = True
    def set_reward(self,reward):
        self.reward = reward