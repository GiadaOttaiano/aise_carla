import sys
import multiprocessing
import glob
import os
sys.path.append('lib/')
from rl_dqn import RL_DQN
import logging
from datetime import datetime
import time

budget_in_hour = 4
budget_in_minutes = budget_in_hour*60

def run():
    target_objective = 1

    rl_dqn = RL_DQN(target_objective,budget_in_minutes)
    rl_dqn.run()

if __name__ == "__main__":
    #
    print("in main")
    multiprocessing.set_start_method('spawn', force=True)

    times_of_repetitions = 4

    for i in range(0, times_of_repetitions):
        manager = multiprocessing.Manager()
        archive = manager.list()
        p = multiprocessing.Process(target=run, name="run")
        p.start()
        for t in range(budget_in_minutes):
            if p.is_alive():
                time.sleep(60)
            else:
                break
        p.terminate()
        # Cleanup
        p.join()
